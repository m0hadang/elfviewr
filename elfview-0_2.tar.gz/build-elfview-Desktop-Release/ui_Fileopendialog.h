/********************************************************************************
** Form generated from reading UI file 'Fileopendialog.ui'
**
** Created by: Qt User Interface Compiler version 5.2.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FILEOPENDIALOG_H
#define UI_FILEOPENDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QTreeView>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_FileOpenDialog
{
public:
    QVBoxLayout *verticalLayout;
    QTreeView *treeView;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *FileOpenDialog)
    {
        if (FileOpenDialog->objectName().isEmpty())
            FileOpenDialog->setObjectName(QStringLiteral("FileOpenDialog"));
        FileOpenDialog->resize(836, 559);
        verticalLayout = new QVBoxLayout(FileOpenDialog);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        treeView = new QTreeView(FileOpenDialog);
        treeView->setObjectName(QStringLiteral("treeView"));

        verticalLayout->addWidget(treeView);

        buttonBox = new QDialogButtonBox(FileOpenDialog);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        verticalLayout->addWidget(buttonBox);


        retranslateUi(FileOpenDialog);
        QObject::connect(buttonBox, SIGNAL(accepted()), FileOpenDialog, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), FileOpenDialog, SLOT(reject()));

        QMetaObject::connectSlotsByName(FileOpenDialog);
    } // setupUi

    void retranslateUi(QDialog *FileOpenDialog)
    {
        FileOpenDialog->setWindowTitle(QApplication::translate("FileOpenDialog", "Dialog", 0));
    } // retranslateUi

};

namespace Ui {
    class FileOpenDialog: public Ui_FileOpenDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FILEOPENDIALOG_H
